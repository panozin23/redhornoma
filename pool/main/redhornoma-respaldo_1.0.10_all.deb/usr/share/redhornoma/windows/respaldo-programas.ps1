# redhornoma · respaldo-programas.ps1
#
# Se ejecuta DENTRO del Windows del centro, una vez al dia, y deja en la
# carpeta compartida una copia de SOAPS y de SNIS lista para recoger.
#
# Por que existe: hasta el 08/08/2026 esas dos copias las tenia que generar
# una persona a mano desde cada programa. Al mirarlo, el ultimo respaldo de
# SOAPS era del 1 de julio: cinco semanas. Un respaldo que depende de que
# alguien se acuerde es un respaldo que no ocurre.
#
# SALMI no se toca aqui: de eso ya se encarga redhornoma-respaldo desde
# Linux, que ademas congela el disco para que la copia salga entera.
#
# Uso:
#   powershell -ExecutionPolicy Bypass -File respaldo-programas.ps1
#   powershell ... -File respaldo-programas.ps1 -Destino D:\RESPALDOS

# Cuantos paquetes se guardan en el Windows. El historial largo lo lleva
# Linux, que tiene disco y ademas se lo lleva fuera del edificio.
$Conservar = 2

# Se puede fijar el destino por delante:  $Destino = "D:\RESPALDOS"
# Si no, se elige solo mas abajo.
if (-not (Test-Path variable:Destino)) { $Destino = "" }

# ── Donde dejarlo ─────────────────────────────────────────────────────
# Si este Windows vive dentro de RedHornoma, tiene la carpeta compartida
# del anfitrion: dejarlo ahi es INSTANTANEO, porque esa carpeta ya ES un
# directorio de Linux. Sacar 60 MB por el canal del agente invitado serian
# cientos de viajes de medio mega.
#
# Si no la alcanza —el Windows fisico de un centro que ya estaba— se deja
# en disco local y Linux lo recoge por la red con smbclient.
if (-not $Destino) {
    $compartida = "\\192.168.122.1\compartido"
    if (Test-Path $compartida) { $Destino = Join-Path $compartida "RESPALDOS" }
    else                       { $Destino = "C:\RESPALDOS" }
}

$ErrorActionPreference = "Continue"
$hoy    = Get-Date -Format "yyyyMMdd"
$inicio = Get-Date
$trabajo = Join-Path $env:TEMP "redhornoma-respaldo-$hoy"
$avisos = New-Object System.Collections.ArrayList

function Paso($t) { Write-Output "== $t" }
function Bien($t) { Write-Output "   OK   $t" }
function Mal($t)  { Write-Output "   FALLO $t"; [void]$avisos.Add($t) }
function Ojo($t)  { Write-Output "   AVISO $t"; [void]$avisos.Add($t) }

if (Test-Path $trabajo) { Remove-Item $trabajo -Recurse -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $trabajo -Force | Out-Null
if (-not (Test-Path $Destino)) { New-Item -ItemType Directory -Path $Destino -Force | Out-Null }

# ── SOAPS: se lo pedimos a SQL Server ─────────────────────────────────
# Copiar los .mdf a mano NO vale: el motor los tiene abiertos y la copia
# sale rota. Hay que pedirle un respaldo de verdad, y verificarlo despues:
# un respaldo sin verificar no es un respaldo.
Paso "SOAPS (SQL Server)"

$sqlcmd = $null
foreach ($v in @(160,150,140,130,120,110,100)) {
    $p = "C:\Program Files\Microsoft SQL Server\$v\Tools\Binn\SQLCMD.EXE"
    if (Test-Path $p) { $sqlcmd = $p; break }
}

if (-not $sqlcmd) {
    Ojo "no encuentro sqlcmd - se salta SOAPS"
} else {
    # Que instancia. La de SOAPS se llama SUIS, pero se busca por si acaso.
    $inst = Get-Service | Where-Object { $_.Name -like "MSSQL`$*" -and $_.Status -eq "Running" } |
            ForEach-Object { $_.Name -replace '^MSSQL\$','' } | Select-Object -First 1
    if (-not $inst) { $inst = "SUIS" }
    $srv = ".\$inst"

    # Las bases del usuario, preguntando al motor. Nada de listas fijas:
    # si manana anaden una base, esto la coge sola.
    $bases = & $sqlcmd -S $srv -E -h -1 -W -Q `
        "SET NOCOUNT ON; SELECT name FROM sys.databases WHERE database_id > 4 AND state = 0;" 2>&1 |
        Where-Object { $_ -match '^\S+$' -and $_ -notmatch 'Msg |Level |Sqlcmd' }

    if (-not $bases) {
        Mal "no pude preguntarle sus bases a SQL Server ($srv)"
    }
    foreach ($b in $bases) {
        $bak = Join-Path $trabajo "$b.bak"
        & $sqlcmd -S $srv -E -b -Q "BACKUP DATABASE [$b] TO DISK = N'$bak' WITH INIT, CHECKSUM;" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { Mal "no se pudo respaldar $b"; continue }
        & $sqlcmd -S $srv -E -b -Q "RESTORE VERIFYONLY FROM DISK = N'$bak' WITH CHECKSUM;" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { Mal "$b se respaldo pero NO VERIFICA"; Remove-Item $bak -Force -EA SilentlyContinue; continue }
        Bien ("{0}  ({1} MB)" -f $b, [math]::Round((Get-Item $bak).Length/1MB,1))
    }
}

# ── SNIS: son archivos de Access ──────────────────────────────────────
# Aqui si vale copiar los archivos, pero solo si NADIE los tiene abiertos.
# Access deja un .ldb junto a cada base mientras alguien esta dentro; si
# lo hay, la copia puede salir a medias. Se copia igual —mejor eso que
# nada— pero se deja dicho en el nombre, para que nadie confie en ella
# sin saberlo.
Paso "SNIS (Access)"

$snis = "C:\SNIS2026"
if (-not (Test-Path $snis)) {
    Ojo "no existe $snis - se salta SNIS"
} else {
    $abierto = @(Get-ChildItem $snis -Filter *.ldb -EA SilentlyContinue).Count -gt 0
    $carpeta = Join-Path $trabajo "SNIS2026"
    New-Item -ItemType Directory -Path $carpeta -Force | Out-Null
    $n = 0
    foreach ($f in Get-ChildItem $snis -Filter *.mdb -EA SilentlyContinue) {
        try {
            Copy-Item $f.FullName -Destination $carpeta -ErrorAction Stop
            Bien ("{0}  ({1} MB)" -f $f.Name, [math]::Round($f.Length/1MB,1))
            $n++
        } catch { Mal ("no se pudo copiar {0}" -f $f.Name) }
    }
    if ($n -eq 0) { Mal "no se copio ninguna base de SNIS" }
    if ($abierto) { Ojo "SNIS estaba ABIERTO: la copia de sus bases puede estar a medias" }
}

# ── Empaquetar ────────────────────────────────────────────────────────
# Los .bak de SQL Server son muy repetitivos y encogen mucho. Eso es lo
# que hace que quepan en la nube de un centro con internet rural, que era
# la razon por la que hasta ahora no se recogian.
Paso "Empaquetando"

$sufijo = ""
if ($avisos.Count -gt 0) { $sufijo = "-CON-AVISOS" }
$zip = Join-Path $Destino ("programas-{0}{1}.zip" -f $hoy, $sufijo)
if (Test-Path $zip) { Remove-Item $zip -Force -EA SilentlyContinue }

# Un parte dentro del paquete: quien lo hizo, cuando, y que fallo.
$parte = Join-Path $trabajo "PARTE.txt"
@(
  "Respaldo de programas - RedHornoma"
  ("Equipo:  {0}" -f $env:COMPUTERNAME)
  ("Fecha:   {0}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
  ""
  "Contenido:"
) + @(Get-ChildItem $trabajo -Recurse -File | ForEach-Object {
        "  {0}  ({1} MB)" -f $_.Name, [math]::Round($_.Length/1MB,1) }) + @(
  ""
  $(if ($avisos.Count -eq 0) { "Sin avisos: la copia es de fiar." }
    else { "AVISOS - no fiarse del todo:" })
) + @($avisos | ForEach-Object { "  - $_" }) | Set-Content $parte -Encoding UTF8

try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($trabajo, $zip,
        [System.IO.Compression.CompressionLevel]::Optimal, $false)
    $mb = [math]::Round((Get-Item $zip).Length/1MB,1)
    Bien ("{0}  ({1} MB)" -f (Split-Path $zip -Leaf), $mb)
} catch {
    Mal ("no se pudo empaquetar: {0}" -f $_.Exception.Message)
}

# ── Dejar sitio ───────────────────────────────────────────────────────
# En el Windows solo se guardan las ultimas: el historial largo lo lleva
# Linux, que tiene disco y ademas se lo lleva fuera del edificio.
Get-ChildItem $Destino -Filter "programas-*.zip" -EA SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -Skip $Conservar |
    ForEach-Object { Remove-Item $_.FullName -Force -EA SilentlyContinue }

Remove-Item $trabajo -Recurse -Force -EA SilentlyContinue

$seg = [math]::Round(((Get-Date) - $inicio).TotalSeconds)
Write-Output ""
if ($avisos.Count -eq 0) { Write-Output "LISTO en $seg s - sin avisos" }
else { Write-Output ("TERMINADO en {0} s CON {1} AVISO(S)" -f $seg, $avisos.Count) }
